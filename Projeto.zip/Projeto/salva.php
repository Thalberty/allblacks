Access-Control-Allow-Origin: index.html

<?php

// Access-Control-Allow-Origin: http://www.example.com

echo "PHP Works";